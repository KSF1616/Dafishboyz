// Direct URL to the DAFISH BOYZ logo in Supabase storage
// Bucket: Logo, File: dafishboyz-logo.png

export const DAFISH_BOYZ_LOGO_URL = 'https://yrfjejengmkqpjbluexn.supabase.co/storage/v1/object/public/Logo/dafishboyz-logo.png';

// Export as default for easy importing
export default DAFISH_BOYZ_LOGO_URL;
