SHITZ CREEK GAME CARDS - UPLOAD INSTRUCTIONS
=============================================

HOW TO ADD YOUR PDF:
1. Locate this folder on your computer: /public/game-cards/
2. Copy your PDF file into this folder
3. Rename your PDF to: shitz-creek-cards.pdf
4. Restart the development server if running

The game will automatically load cards from:
/game-cards/shitz-creek-cards.pdf

ALTERNATIVE - Individual Card Images:
If you have separate card images, add them as:
- card-1.png (or .jpg)
- card-2.png
- card-3.png
- etc.

SUPPORTED FORMATS:
- PDF files (.pdf)
- Images (.png, .jpg, .jpeg, .webp)

After adding your file, refresh the browser to see the cards in the game lobby.
